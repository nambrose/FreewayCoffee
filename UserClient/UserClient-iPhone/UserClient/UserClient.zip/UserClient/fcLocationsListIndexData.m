//
//  fcLocationsListIndexData.m
//  UserClient
//
//  Created by Nick Ambrose on 1/19/13.
//  Copyright (c) 2013 Freeway Coffee. All rights reserved.
//

#import "fcLocationsListIndexData.h"

@implementation fcLocationsListIndexData
@synthesize locationID=_locationID;

@end
