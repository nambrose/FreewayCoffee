//
//  fcLeftMenuIndexItem.m
//  UserClient
//
//  Created by Nick Ambrose on 2/17/13.
//  Copyright (c) 2013 Freeway Coffee. All rights reserved.
//

#import "fcLeftMenuIndexItem.h"

@implementation fcLeftMenuIndexItem


@synthesize ItemType=_ItemType;
@synthesize ItemText=_ItemText;

@end
