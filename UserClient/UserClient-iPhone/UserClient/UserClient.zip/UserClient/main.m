//
//  main.m
//  UserClient
//
//  Created by Nick Ambrose on 9/5/12.
//  Copyright (c) 2012 Nick Ambrose. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "fcAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([fcAppDelegate class]));
    }
}
