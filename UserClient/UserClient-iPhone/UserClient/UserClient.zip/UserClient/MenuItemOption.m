//
//  MenuItemOption.m
//  UserClient
//
//  Created by Nick Ambrose on 9/3/12.
//  Copyright (c) 2012 Immerse Images. All rights reserved.
//

#import "MenuItemOption.h"

@implementation MenuItemOption
@synthesize OptionID=_optionID;;
@synthesize OptionGroupID=_optionGroupID;
@synthesize OptionName=_optionName;
@synthesize SortOrder=_sortOrder;
@end;