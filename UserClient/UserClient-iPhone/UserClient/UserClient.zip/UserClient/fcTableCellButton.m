#import "fcTableCellButton.h"


@implementation fcTableCellButton
@synthesize cellIndex;
@end