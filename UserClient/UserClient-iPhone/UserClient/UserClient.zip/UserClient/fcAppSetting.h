//
//  fcAppSetting.h
//  UserClient
//
//  Created by Nick Ambrose on 9/29/12.
//  Copyright (c) 2012 Freeway Coffee. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface fcAppSetting : NSObject

@property (nonatomic,copy) NSString *appSettingName;
@property (nonatomic,copy) NSString *appSettingValue;
@end
