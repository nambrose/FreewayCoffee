//
//  fcAppSetting.m
//  UserClient
//
//  Created by Nick Ambrose on 9/29/12.
//  Copyright (c) 2012 Freeway Coffee. All rights reserved.
//

#import "fcAppSetting.h"

@implementation fcAppSetting
@synthesize appSettingName=_appSettingName;
@synthesize appSettingValue=_appSettingValue;
@end
