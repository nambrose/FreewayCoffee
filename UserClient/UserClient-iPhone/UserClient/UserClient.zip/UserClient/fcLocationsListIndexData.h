//
//  fcLocationsListIndexData.h
//  UserClient
//
//  Created by Nick Ambrose on 1/19/13.
//  Copyright (c) 2013 Freeway Coffee. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface fcLocationsListIndexData : NSObject

@property (nonatomic,strong) NSNumber *locationID;

@end
