//
//  fcMenuItemMandatoryOption.m
//  UserClient
//
//  Created by Nick Ambrose on 9/8/12.
//  Copyright (c) 2012 Nick Ambrose. All rights reserved.
//

#import "fcMenuItemMandatoryOption.h"

@implementation fcMenuItemMandatoryOption

@synthesize itemTypeID;
@synthesize itemGroupID;

-(id)init
{
    self = [super init];
    if (self)
    {
        
    }
    return self;
}

@end
